"""Reusable command-line EDA summary for the European banking churn dataset."""
import argparse
import pandas as pd

REQUIRED = ["CreditScore", "Geography", "Gender", "Age", "Tenure", "Balance",
            "NumOfProducts", "HasCrCard", "IsActiveMember", "EstimatedSalary", "Exited"]

def main(path):
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    df = df.drop(columns=["Surname"], errors="ignore").copy()
    df["Exited"] = pd.to_numeric(df["Exited"], errors="coerce")
    df = df[df["Exited"].isin([0, 1])]
    print(f"Rows analysed: {len(df):,}")
    print(f"Overall churn rate: {df['Exited'].mean():.2%}")
    for col in ["Geography", "Gender"]:
        print(f"\\nChurn by {col}:")
        print((df.groupby(col)["Exited"].agg(["count", "sum", "mean"])
                 .rename(columns={"count":"Customers","sum":"Churned","mean":"ChurnRate"})
                 .to_string()))
    df["AgeGroup"] = pd.cut(df["Age"], [0,29,45,60,float("inf")],
                            labels=["Below 30","30–45","46–60","60+"])
    print("\\nChurn by age group:")
    print(df.groupby("AgeGroup", observed=True)["Exited"].agg(["count","sum","mean"]).to_string())

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path", help="Path to the source customer churn CSV")
    main(parser.parse_args().csv_path)
