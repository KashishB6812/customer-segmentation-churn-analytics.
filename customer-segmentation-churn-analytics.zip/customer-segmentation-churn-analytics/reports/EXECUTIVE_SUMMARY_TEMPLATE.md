# Executive Summary — European Banking Customer Churn

## Purpose
Identify customer segments with elevated churn and translate findings into retention actions.

## Dataset and scope
- Source: [insert dataset source and access date]
- Number of valid records: [calculate from actual dataset]
- Countries represented: [confirm from data]
- Target: `Exited` (1 = churned, 0 = retained)

## Key findings
1. Overall churn rate: [calculate]
2. Highest-risk geography: [calculate]
3. Highest-risk age segment: [calculate]
4. High-value customer churn: [calculate using a documented value definition]
5. Inactivity and churn relationship: [calculate]

## Recommendations
- Design retention campaigns for segments with high churn rates and meaningful customer counts.
- Contact inactive customers with relevant engagement offers.
- Review service/product fit for high-value customers at risk.
- Track churn rate and customer retention by segment over time.

## Limitations
Churn associations are descriptive and do not prove causation. Estimated salary and account balance are not equivalent to bank revenue or customer lifetime value. Define a validated value metric before quantifying revenue at risk.
