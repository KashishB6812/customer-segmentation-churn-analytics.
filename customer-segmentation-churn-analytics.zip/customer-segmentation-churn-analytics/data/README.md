Place the source CSV dataset in this folder or upload it directly in the Streamlit app.

Expected core columns: CreditScore, Geography, Gender, Age, Tenure, Balance,
NumOfProducts, HasCrCard, IsActiveMember, EstimatedSalary, Exited.

Do not commit personal/customer-level data to a public repository unless you have
permission and have checked that it contains no confidential or identifying information.
