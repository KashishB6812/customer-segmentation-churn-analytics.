# Customer Segmentation & Churn Pattern Analytics in European Banking

An interactive Streamlit analytics project to explore customer churn across geography, demographics, tenure, engagement, credit score and financial profile.

## Features
- Overall churn KPIs
- Geography, age, gender, tenure and credit-score comparisons
- Balance segmentation and high-value customer exploration
- Interactive filters and segment-level summary table
- Reusable command-line EDA summary
- Executive summary template

## Dataset
Upload the CSV using the dashboard sidebar. The expected core fields are:

`CreditScore, Geography, Gender, Age, Tenure, Balance, NumOfProducts, HasCrCard, IsActiveMember, EstimatedSalary, Exited`

`CustomerId` and `Surname` may also be present; they are not required by the dashboard. The app validates required fields and removes rows with missing required values.

**Important:** This repository does not include the source dataset. Add the dataset only if its licence permits redistribution. Avoid publishing customer-identifiable or confidential records.

## Run locally
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Run the EDA script
```bash
python analysis.py path/to/your_dataset.csv
```

## Methodology
- Churn rate = customers with `Exited = 1` divided by customers in the segment.
- Age groups: Below 30, 30–45, 46–60, 60+.
- Credit score bands: Low (<580), Medium (580–699), High (700+).
- Tenure groups: New (0–2 years), Mid-term (3–6), Long-term (7–10).
- Balance groups: zero balance, below-median positive balance, and median-or-higher balance.
- High-value proxy: top quartile of `Balance + EstimatedSalary`. This is a transparent analytical proxy, not actual customer profitability or revenue.

## Project limitations
The dashboard is descriptive. Segment differences do not establish why a customer churned. Revenue-at-risk cannot be reliably calculated from balance and estimated salary alone.

## Suggested repository structure
```text
customer-segmentation-churn-analytics/
├── app.py
├── analysis.py
├── requirements.txt
├── README.md
├── data/
│   └── README.md
└── reports/
    └── EXECUTIVE_SUMMARY_TEMPLATE.md
```

## Author
[Add your name]

## Acknowledgement
Project brief: Unified Mentor — Customer Segmentation & Churn Pattern Analytics in European Banking.
