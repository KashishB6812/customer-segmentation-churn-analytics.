import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="European Banking | Churn Analytics", page_icon="🏦", layout="wide")
st.title("🏦 Customer Segmentation & Churn Pattern Analytics")
st.caption("European Banking | Interactive customer churn dashboard")

REQUIRED = ["CreditScore", "Geography", "Gender", "Age", "Tenure", "Balance",
            "NumOfProducts", "HasCrCard", "IsActiveMember", "EstimatedSalary", "Exited"]

uploaded = st.sidebar.file_uploader("Upload customer churn CSV", type=["csv"])
if uploaded is None:
    st.info("Upload the project dataset (CSV) from the sidebar to explore the dashboard.")
    st.markdown("""
    **Expected dataset columns:** `CustomerId`, `Surname`, `CreditScore`, `Geography`,
    `Gender`, `Age`, `Tenure`, `Balance`, `NumOfProducts`, `HasCrCard`,
    `IsActiveMember`, `EstimatedSalary`, `Exited`.

    The app also accepts files without `CustomerId` or `Surname`.
    """)
    st.stop()

df = pd.read_csv(uploaded)
missing = [c for c in REQUIRED if c not in df.columns]
if missing:
    st.error("Required columns missing: " + ", ".join(missing))
    st.stop()

for col in ["CreditScore", "Age", "Tenure", "Balance", "NumOfProducts",
            "HasCrCard", "IsActiveMember", "EstimatedSalary", "Exited"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")
df = df.dropna(subset=REQUIRED).copy()
df = df[df["Exited"].isin([0, 1])]
if df.empty:
    st.error("No valid rows remain after data validation.")
    st.stop()

def band_credit(x):
    if x < 580: return "Low"
    if x < 700: return "Medium"
    return "High"

def band_balance(x):
    if x == 0: return "Zero-balance"
    if x < df["Balance"].median(): return "Low-balance"
    return "High-balance"

df["AgeGroup"] = pd.cut(df["Age"], bins=[0, 29, 45, 60, float("inf")],
                        labels=["Below 30", "30–45", "46–60", "60+"], right=True)
df["CreditBand"] = df["CreditScore"].apply(band_credit)
df["TenureGroup"] = pd.cut(df["Tenure"], bins=[-1, 2, 6, 10],
                           labels=["New (0–2)", "Mid-term (3–6)", "Long-term (7–10)"])
df["BalanceSegment"] = df["Balance"].apply(band_balance)
df["CustomerValue"] = df["Balance"] + df["EstimatedSalary"]
value_cutoff = df["CustomerValue"].quantile(0.75)
df["ValueSegment"] = df["CustomerValue"].apply(lambda x: "High-value" if x >= value_cutoff else "Other")

st.sidebar.header("Segment filters")
geos = st.sidebar.multiselect("Geography", sorted(df["Geography"].dropna().unique()), default=sorted(df["Geography"].dropna().unique()))
genders = st.sidebar.multiselect("Gender", sorted(df["Gender"].dropna().unique()), default=sorted(df["Gender"].dropna().unique()))
age_groups = st.sidebar.multiselect("Age group", df["AgeGroup"].cat.categories.tolist(), default=df["AgeGroup"].cat.categories.tolist())
view = df[df["Geography"].isin(geos) & df["Gender"].isin(genders) & df["AgeGroup"].isin(age_groups)].copy()
if view.empty:
    st.warning("No customers match the selected filters.")
    st.stop()

total = len(view)
churned = int(view["Exited"].sum())
rate = view["Exited"].mean() * 100
high = view[view["ValueSegment"] == "High-value"]
high_rate = high["Exited"].mean() * 100 if len(high) else 0
inactive_rate = view.loc[view["IsActiveMember"] == 0, "Exited"].mean() * 100 if (view["IsActiveMember"] == 0).any() else 0

k1, k2, k3, k4 = st.columns(4)
k1.metric("Customers", f"{total:,}")
k2.metric("Churned customers", f"{churned:,}")
k3.metric("Overall churn rate", f"{rate:.1f}%")
k4.metric("High-value churn rate", f"{high_rate:.1f}%")

st.subheader("Overall churn summary")
left, right = st.columns(2)
with left:
    counts = view["Exited"].map({0: "Retained", 1: "Churned"}).value_counts().rename_axis("Status").reset_index(name="Customers")
    st.plotly_chart(px.pie(counts, names="Status", values="Customers", hole=.45, title="Retained vs churned customers"), use_container_width=True)
with right:
    geo = view.groupby("Geography", observed=True).agg(Customers=("Exited", "size"), Churn_Rate=("Exited", "mean")).reset_index()
    geo["Churn Rate (%)"] = geo["Churn_Rate"] * 100
    st.plotly_chart(px.bar(geo, x="Geography", y="Churn Rate (%)", text_auto=".1f", title="Churn rate by geography"), use_container_width=True)

st.subheader("Demographic and relationship patterns")
a, b = st.columns(2)
with a:
    age = view.groupby("AgeGroup", observed=True)["Exited"].mean().mul(100).reset_index(name="Churn Rate (%)")
    st.plotly_chart(px.bar(age, x="AgeGroup", y="Churn Rate (%)", title="Churn rate by age group"), use_container_width=True)
with b:
    tenure = view.groupby("TenureGroup", observed=True)["Exited"].mean().mul(100).reset_index(name="Churn Rate (%)")
    st.plotly_chart(px.bar(tenure, x="TenureGroup", y="Churn Rate (%)", title="Churn rate by tenure"), use_container_width=True)

c, d = st.columns(2)
with c:
    gender = view.groupby("Gender")["Exited"].mean().mul(100).reset_index(name="Churn Rate (%)")
    st.plotly_chart(px.bar(gender, x="Gender", y="Churn Rate (%)", title="Churn rate by gender"), use_container_width=True)
with d:
    credit = view.groupby("CreditBand")["Exited"].mean().mul(100).reindex(["Low", "Medium", "High"]).reset_index(name="Churn Rate (%)")
    st.plotly_chart(px.bar(credit, x="CreditBand", y="Churn Rate (%)", title="Churn rate by credit-score band"), use_container_width=True)

st.subheader("Financial profile and high-value customer churn")
e, f = st.columns(2)
with e:
    bal = view.groupby("BalanceSegment")["Exited"].mean().mul(100).reset_index(name="Churn Rate (%)")
    st.plotly_chart(px.bar(bal, x="BalanceSegment", y="Churn Rate (%)", title="Churn rate by balance segment"), use_container_width=True)
with f:
    st.plotly_chart(px.scatter(view, x="Balance", y="EstimatedSalary", color=view["Exited"].map({0:"Retained",1:"Churned"}),
                               hover_data=["Geography","Age","NumOfProducts"], title="Balance vs estimated salary"), use_container_width=True)

st.subheader("Engagement and product indicators")
g, h = st.columns(2)
with g:
    active = view.groupby("IsActiveMember")["Exited"].mean().mul(100).rename(index={0:"Inactive",1:"Active"}).reset_index(name="Churn Rate (%)")
    st.plotly_chart(px.bar(active, x="IsActiveMember", y="Churn Rate (%)", title="Churn by member activity"), use_container_width=True)
with h:
    products = view.groupby("NumOfProducts")["Exited"].mean().mul(100).reset_index(name="Churn Rate (%)")
    st.plotly_chart(px.bar(products, x="NumOfProducts", y="Churn Rate (%)", title="Churn by number of products"), use_container_width=True)

st.subheader("Segment detail")
segment_col = st.selectbox("Choose segmentation dimension", ["Geography", "AgeGroup", "Gender", "CreditBand", "TenureGroup", "BalanceSegment", "ValueSegment"])
summary = view.groupby(segment_col, observed=True).agg(
    Customers=("Exited", "size"), Churned=("Exited", "sum"), Churn_Rate=("Exited", "mean"),
    Average_Balance=("Balance", "mean"), Average_Salary=("EstimatedSalary", "mean")
).reset_index()
summary["Churn_Rate"] = (summary["Churn_Rate"] * 100).round(2)
st.dataframe(summary, use_container_width=True, hide_index=True)

st.caption("Definitions: churn rate = exited customers ÷ customers in the selected group. High-value is defined here as the top quartile of Balance + EstimatedSalary; adjust this proxy to match the project brief or business definition.")
